rrdpath = './RRD/'
pngpath = './IMG/'
rrdname= "testPredict.rrd"
pngfname="testPredict.png"
