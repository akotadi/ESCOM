package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ;
import java.util.* ;
import servletbible.ch11.examples.*;


/**
 * Servlet to add items to cart
 *
 */
public class AddToCart extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Addes the selected item to the cart
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet( HttpServletRequest req, HttpServletResponse res )
        throws ServletException, IOException {
        PrintWriter out = res.getWriter() ;
        
        HttpSession session = req.getSession() ;
        if (session.getValue("userId")!=null) {
            String userId = (String) session.getValue( "userId" ) ;
            out.println( "<html><body><center>" ) ;
            out.println( "Welcome " + userId + "!" ) ;
      
            // Get the selected item from the request and add it to the cart
            if (req.getParameter("itemcode")!=null) {
                String code = (String) req.getParameter("itemcode") ;
                ItemManager itemMgr = new ItemManager() ;
                Item item = itemMgr.getItemDetails(code) ;
                Vector selectedItems ;
                if (session.getValue(userId)!=null) {
                    selectedItems = (Vector) session.getValue(userId) ;
                }
                else{
                    selectedItems = new Vector() ;
                }
                selectedItems.add( item ) ;
                session.putValue(userId,selectedItems) ;
                session.putValue(code,item) ;
                out.print("<br><br>The item was added to " );
                out.println( "your shopping cart<BR><br>" ) ;
                out.println("<a href='" + res.encodeURL("showlist") + 
                    "'>Click here to continue shopping</a>") ;
                out.println("<br><a href='" + res.encodeURL("logout") +
                    "'>Click here to Logout</a>") ;
            }
        }
        else{
            out.println("Session timeout error") ;
        }
    }
}