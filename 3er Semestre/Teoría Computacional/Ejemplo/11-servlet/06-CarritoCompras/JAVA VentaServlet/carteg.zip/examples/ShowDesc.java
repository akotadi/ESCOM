package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ; 
import java.util.* ;
import servletbible.ch11.examples.*;

/** 
 * Servlet to show item descriptions and summary
 */
public class ShowDesc extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Displays the details of the selected item
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req,
        HttpServletResponse res) 
        throws ServletException, IOException {
            
        PrintWriter out = res.getWriter() ;
        ItemManager itemMgr = new ItemManager() ;
        HttpSession session = req.getSession() ;
        out.println("<html><body>") ;
        if (session.getValue("userId")!=null) {
            out.println("Welcome " + session.getValue("userId") + "!" ) ;
            String code ;
            if (req.getParameter("itemcode")!=null) {
                code = (String) req.getParameter("itemcode") ;
                Item item = itemMgr.getItemDetails(code);
                out.print("<table border = 1><tr><th>" );
                out.print( "Commodity</th><th>Summary</th>" );
                out.println( "<th>Price</th></tr>" );
                out.println("<tr><td valign = top>" + 
                    item.getItemDesc() + "</td><td valign = top width = 300 >" +
                    item.getItemSummary() + "</td><td valign = bottom >" + 
                    item.getItemPrice() + "</td></tr>") ;
                out.println("</table>") ;
                out.println("<br><br><br><a href='" + 
                    res.encodeURL( "addtocart" ) +
                    "?itemcode=" + 
                    code + "'> Add this Item to cart </a><br>") ;
                out.println("<a href='" + res.encodeURL("checkout" ) +
                    "'>Proceed to check out </a><br>") ;
                out.println("<a href='" + res.encodeURL("showlist") + 
                    "'>Continue shopping </a><br>") ;
                out.println("<a href='" + res.encodeURL("viewcart") +
                    "'>View shopping cart</a><br>") ;
                out.println("<a href='" + res.encodeURL("logout") +
                    "'>Click here to logout</a>") ;
            }
            else {
                out.println("The specified Item is no longer available") ;
            }
        }
        else{
            out.println("Session time out error") ;
        }
        out.println("</body></html>") ;
    }
}