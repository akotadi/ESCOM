package servletbible.ch11.examples;

import java.sql.* ;
import java.util.* ;

/**
 * Manager bean to handle item related transactions
 */
public class ItemManager {
    
    /**
     * Returns all the items from the <i>item</i> table
     *
     * @return Enumeration List of all items
     */
    public Enumeration getItemList() throws SQLException {
        Connection con = null;
        Statement st = null;
        try {
            con = DBManager.getConnection() ;
            st = con.createStatement() ;
            ResultSet rs = st.executeQuery("Select * from item") ;
            Vector itemList = new Vector() ;
            while (rs.next()) {
                Item myItem = new Item() ;
                myItem.setItemCode(rs.getString("itemcode")) ;
                myItem.setItemDesc(rs.getString("itemdesc")) ;
                myItem.setItemSummary(rs.getString("summary")) ;
                myItem.setItemPrice(rs.getDouble("itemprice")) ;
                itemList.add(myItem) ;
            }
            rs.close();
            return itemList.elements() ;
        } catch(Exception e) {
            e.printStackTrace() ;
        } finally {
            if( st != null ) {
                st.close();
            }
            if( con != null ) {
                con.close();
            }
        }
        return null ;
    }
    
    /**
     * Returns the details for a particular item
     *
     * @param itemCode Item to get the details for
     * @return Item
     */
    public Item getItemDetails(String itemCode) {
        try {
            Connection con = DBManager.getConnection() ;
            Statement st = con.createStatement() ;
            ResultSet rs = st.executeQuery("Select * from item where itemcode = '" + itemCode + "'") ;
            if (rs.next()){
                Item myItem = new Item() ;
                myItem.setItemCode(rs.getString("itemcode")) ;
                myItem.setItemDesc(rs.getString("itemdesc")) ;
                myItem.setItemSummary(rs.getString("summary")) ;
                myItem.setItemPrice(rs.getDouble("itemprice")) ;
                return myItem ;
            }
            
        }
        catch(Exception e) {
            e.printStackTrace() ;
        }
        return null ;
    }
    
    /**
     * Returns the details for the given comma separated item codes
     *
     * @param itemCodes comma separated list of item codes
     */
    public Enumeration getSelectedItems(String itemCodes) {
        try {
            Connection con = DBManager.getConnection() ;
            Statement st = con.createStatement() ;
            ResultSet rs = st.executeQuery( 
                "select * from item where itemcode in (" + 
                itemCodes + ")" ) ;
            Vector itemList = new Vector() ;
            String last = null;
            while (rs.next()){
                Item myItem = new Item() ;
                myItem.setItemCode(rs.getString("itemcode")) ;
                myItem.setItemDesc(rs.getString("itemdesc")) ;
                myItem.setItemSummary(rs.getString("summary")) ;
                myItem.setItemPrice(rs.getDouble("itemprice")) ;
                itemList.add(myItem) ;
            }
            return itemList.elements() ;
        }
        catch(Exception e) {
            e.printStackTrace() ;
        }
        return null ;
    }
}