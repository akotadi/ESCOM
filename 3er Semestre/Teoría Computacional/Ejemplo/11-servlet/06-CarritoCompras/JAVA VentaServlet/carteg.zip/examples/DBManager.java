package servletbible.ch11.examples;
import java.sql.* ;

/**
 * Bean for handling database connections.
 * Enhance the getConnection method to provide connection pooling support or other support
 * @author Suresh M.V.
 * @date   5th June 2001
 */
public class DBManager {
    /**
     * Returns a new JDBC connection
     * 
     * @return Connection New JDBC Connection
     */
    public static Connection getConnection() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver") ;
            return (DriverManager.getConnection("jdbc:odbc:carteg","","") );
        }
        catch(Exception e) {
            e.printStackTrace() ;
        }
        return null ;
    }
}
