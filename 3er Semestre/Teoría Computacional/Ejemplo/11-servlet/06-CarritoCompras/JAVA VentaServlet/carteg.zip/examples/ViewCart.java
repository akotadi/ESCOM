package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ; 
import java.util.* ;
import servletbible.ch11.examples.*;

/** 
 * Servlet to display the status of the shopping cart at any given time
 */
public class ViewCart extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Handles HTTP GET request
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req,
        HttpServletResponse res) 
        throws ServletException, IOException {
        doPost(req,res) ;
    }
    
    /**
     * Displays the virtual shopping cart
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doPost(HttpServletRequest req,
        HttpServletResponse res) 
        throws ServletException, IOException {
        PrintWriter out = res.getWriter() ;
        ItemManager itemMgr = new ItemManager() ;
        out.println("<html><body><center>" );
        out.println( "<form name='deleteform' method = 'post' " );
        out.println( "action = '" + res.encodeURL("deleteitems") + "'>") ;
        HttpSession session = req.getSession() ;
        if (session.getValue("userId")!=null) {
            String userId = (String) session.getValue("userId") ;
            
            out.println("Welcome " + userId + "!" ) ;
            Vector selectedItems ;
            if (session.getValue(userId)!=null) {
                selectedItems = (Vector) session.getValue(userId) ;
                Enumeration list = selectedItems.elements() ;
                out.println("<table border = 1><tr><th>" );
                out.println("Commodity</th><th>Price</th></tr>") ;

                while (list.hasMoreElements()) {
                    Item item = (Item) list.nextElement() ;
                    out.println("<tr><td valign = top>");
                    out.println("<input type='checkbox' name='" + 
                        item.getItemCode() + 
                        "'><a href='" + res.encodeURL("showdesc") +
                        "?itemcode="+item.getItemCode()+"'>" + 
                        item.getItemDesc() + "</td><td align = right>" + 
                        item.getItemPrice() + "</a></td></tr>") ;
                }
                out.println("</table>") ;
                out.println("<br><br><br><a href='javascript:remove()'>" );
                out.println("Delete selected items</a>") ;
            }
            else {
                out.println("<br>The cart is empty") ;
            }
        }
        else{
            out.println("Session timeout error") ;
        }
        out.println("<br><br><br><a href='" + 
            res.encodeURL("showlist") +
            "'>Click here to continue shopping</a>") ;
        out.println("<br><a href='" + 
            res.encodeURL("logout") +
            "'>Click here to logout</a>") ;
        out.println("</form></body>") ;
        out.println("<script language = 'javascript'>") ;
        out.println("function remove() { ") ;
        out.println("document.deleteform.submit(); ") ;
        out.println("}</script></html>") ;
    }
}