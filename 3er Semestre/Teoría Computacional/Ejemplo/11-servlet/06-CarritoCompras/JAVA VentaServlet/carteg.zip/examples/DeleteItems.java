package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ;
import java.util.* ;

/**
 * Servlet to delete items from the shopping cart
 */
public class DeleteItems extends HttpServlet {
    /**
     * Intializes this servlet
     *
     * @param cfg ServletConfig object
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Handles HTTP GET request
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        doPost(req,res) ;
    }
    
    /**
     * Deletes selected items from the cart
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doPost(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        PrintWriter out = res.getWriter() ;
        
        HttpSession session = req.getSession() ;
        if (session.getValue("userId")!=null) {
            String userId = (String) session.getValue("userId") ;
            Vector itemList = (Vector)session.getValue(userId) ;
            Vector newList = new Vector() ;
            int size = itemList.size() ;
            for (int i = 0;i<size;i++) {
                String temp = (String) itemList.elementAt(i) ;
                // != null means that this item has been selected for deletion
                if (req.getParameter(temp)!=null) {
                    session.removeValue(temp) ;
                }
                else{
                    newList.add(temp) ;
                }
            }
            if (newList.size()>0)
                session.putValue(userId,newList) ;
            else
                session.removeValue(userId) ;
            
        }
        RequestDispatcher rd = getServletContext().
                getRequestDispatcher(res.encodeURL("/viewcart"));
        rd.forward(req,res) ;
    }
}