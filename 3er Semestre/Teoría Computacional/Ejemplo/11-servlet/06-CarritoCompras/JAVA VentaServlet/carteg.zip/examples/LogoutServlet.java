package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ;
import servletbible.ch11.examples.*;

/**
 * Logs out the current user
 *
 */

public class LogoutServlet extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Prompts the use to enter userid and password
     * 
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        
        HttpSession session = req.getSession();
        String userId = (String) session.getValue( "userId" );
        session.removeValue( "userId" );
        session.removeValue( userId );
        RequestDispatcher dispatcher = getServletContext().
            getRequestDispatcher( "/login" );
        dispatcher.forward( req, res );
    }
    
    /**
     * Validates the userid and password
     * 
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doPost(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        doGet( req, res );
    }
}