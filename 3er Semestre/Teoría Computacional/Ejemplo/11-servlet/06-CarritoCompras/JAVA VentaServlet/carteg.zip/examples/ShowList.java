package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ; 
import java.util.* ;
import servletbible.ch11.examples.*;

/**
 * Servlet to show the items available in the site
 */
public class ShowList extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Handles HTTP GET request
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req,
        HttpServletResponse res) 
        throws ServletException, IOException {
        doPost(req,res) ;
    }
    
    /**
     * Displays the list of items
     *
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doPost(HttpServletRequest req,
        HttpServletResponse res) 
        throws ServletException, IOException {

       PrintWriter out = res.getWriter() ;

		try
		{
 
        ItemManager itemMgr = new ItemManager() ;
        out.println("<html><body><center>") ;
        HttpSession session = req.getSession() ;
        if (session.getValue("userId")!=null) {
            out.println("Welcome " + session.getValue("userId") + "!" ) ;

			
	        Enumeration list = itemMgr.getItemList() ;
            out.print("<table border = 1><tr><th>");
            out.println("Commodity</th><th>Price</th></tr>") ;
            while (list.hasMoreElements()) {
                Item item = (Item) list.nextElement() ;
                out.println("<tr valign = top><td><a href='");
                out.println(res.encodeURL("showdesc") + "?itemcode="+
                    item.getItemCode() + "'>" + item.getItemDesc() + 
                    "</td><td align = right>" + item.getItemPrice() 
                    + "</a></td></tr>") ;
            }
            out.println("</table>") ;
        }
        else{
            out.println("Session not bound") ;
        }
        out.println("<br><br><br>") ;
        out.println("<a href='" + res.encodeURL("checkout") +
            "'>Proceed to check out </a><br>") ;
        out.println("<a href='" + res.encodeURL("viewcart") + 
            "'>View shopping cart</a><br>") ;
        out.println("<a href='" + res.encodeURL("logout") + 
            "'>Click here to logout</a><br>") ;
        out.println("</center></body></html>") ;

    	}
		catch(Exception e)
		{ 
			out.println("Exception occured while processing page");
			return;
		}


	}   
}