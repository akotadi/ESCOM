package servletbible.ch11.examples;

/**
 * Bean to hold the item information
 */
public class Item {
    
    public String itemCode ;
    public String itemDesc ;
    public String itemSummary ;
    public double itemPrice ;

    /**
     * GETTER methods
     */
    
    public String getItemCode() {
        return itemCode ;
    }
    
    public String getItemDesc() {
        return itemDesc ;
    }
    
    public String getItemSummary() {
        return itemSummary ;
    }
    
    public double getItemPrice() {
        return itemPrice ;
    }
    
    /**
     * SETTER methods
     */
    
    public void setItemCode(String itemCode ) {
        this.itemCode = itemCode ;
    }
    
    public void setItemDesc(String itemDesc) {
        this.itemDesc = itemDesc ;
    }
    
    public void setItemSummary(String itemSummary) {
        this.itemSummary = itemSummary ;
    }
    
    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice ;
    }
    
    public String toString() {
        return "ItemCode = " + itemCode + "ItemDesc = " + 
            itemDesc + "ItemSummary = " + itemSummary + 
            " ItemPrice = " + itemPrice ;
    }
}