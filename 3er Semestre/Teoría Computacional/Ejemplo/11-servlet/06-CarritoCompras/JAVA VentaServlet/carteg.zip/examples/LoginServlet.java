package servletbible.ch11.examples;

import javax.servlet.* ;
import javax.servlet.http.* ;
import java.io.* ;
import servletbible.ch11.examples.*;

/**
 * A shopping cart login servlet
 */

public class LoginServlet extends HttpServlet {

    /**
     * Initializes this servlet
     *
     * @param cfg ServletConfig object
     * @throws ServletException When an exception occurs
     */
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg) ;
    }
    
    /**
     * Prompts the use to enter userid and password
     * 
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doGet(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        
        PrintWriter out = res.getWriter() ;
        if (req.getParameter("login")==null) {
            out.println("<html><body><center>") ;
            out.println("<form name = 'loginform' method = 'post'><table>") ;
            out.println("<tr><td>Enter username:</td>") ;
            out.println("<td><input type = 'text' name = 'userid'></td></tr>") ;
            
            out.println("<tr><td>Enter password:</td>") ;
            out.println("<td><input type = 'password' name = 'passwd'></td></tr>") ;
            out.print("<tr><td><input type = 'submit' " );
            out.println("name = 'login' value='Login'></td></tr>") ;
            out.println("</table></form></center></body></html>") ;
        }
        else {
            doPost(req,res) ;
        }
    }
    
    /**
     * Validates the userid and password
     * 
     * @param req Request object
     * @param res Response object
     * @throws ServletException When an exception occurs
     * @throws IOException When an exception occurs
     */
    public void doPost(HttpServletRequest req, 
        HttpServletResponse res) 
        throws ServletException, IOException {
        
        PrintWriter out = res.getWriter() ;
        String userId, passwd ;
        UserManager login = new UserManager() ;
        if ((req.getParameter("userid")!=null) && (req.getParameter("passwd")!=null)) {
            userId = (String) req.getParameter("userid") ;
            passwd = (String) req.getParameter("passwd") ;
            
            // If successful login
            if (login.validate(userId,passwd)){
                HttpSession session = req.getSession() ;
                session.putValue("userId",userId) ;
                RequestDispatcher rd = getServletContext().
                    getRequestDispatcher(res.encodeURL("/showlist"));
                rd.forward(req,res) ;
            }
            out.println("<html><body><center>Invalid userid or password <br>") ;
            out.println("<a href='" + 
                res.encodeURL("login") + "'>Click here to relogin</a>") ;
            out.println("</body></html>") ;
        }
        else {
            out.print("Login Failed! Please enter valid " );
            out.println( "login details and click login" ) ;
            out.println("<a href = '" + res.encodeURL( "login" ) +
                "'>click here</a>") ;
        }
    }
}
