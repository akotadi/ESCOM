package servletbible.ch11.examples;

import java.sql.* ;

/**
 * Manager Bean for handling user table related operations
 *
 */
public class UserManager {

    /**
     * Validates the userid and password
     *
     * @param userId User id
     * @param passwd Password
     * @return boolean true - if the user is valid
     */
    public boolean validate(String userId, String passwd) {
        try {
            Connection con = DBManager.getConnection() ;
            Statement st = con.createStatement() ;
            ResultSet rs = st.executeQuery( 
                "Select * from user where userid = '" + 
                 userId + "' and password = '" + passwd + "'") ;
            if (rs.next()){
                rs.close();
                st.close();
                con.close();
                return true;
            }
        }
        catch(Exception e) {
            e.printStackTrace() ;
        }
        return false ;
    }   
}